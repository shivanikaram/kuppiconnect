<?php

namespace App\Http\Controllers;

use App\Models\Module;
use App\Models\Tutor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ModuleController extends Controller
{
    public function create()
    {
        return view('tutorDashboard');
    }

    // Store a new module
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        // Ensure the user is logged in and is a tutor
        if (Auth::check() && Auth::user()->tutor) {
            $tutor = Auth::user()->tutor; // Get the logged-in tutor

            // Create the module and associate it with the tutor
            $module = new Module();
            $module->name = $request->name;
            $module->description = $request->description;
            $module->tutor_id = $tutor->tutor_id; // Associate the module with the logged-in tutor
            $module->save();

            return redirect()->route('tutorDashboard')->with('success', 'Module created successfully!');
        }

        return redirect()->route('tutorDashboard')->with('error', 'You must be a logged-in tutor to create a module.');
    }
}

