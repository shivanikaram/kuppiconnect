<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;

class AdminLoginController extends Controller
{
    public function showAdminLoginForm()
    {
        return view('adminLogin');
    }

    public function adminLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        $admin = Admin::where('email', $request->email)->first();

        if ($admin && Hash::check($request->password, $admin->password)) {
            session(['admin_logged_in' => true]); // Admin session
            return redirect()->route('adminDashboard');
        }

        return back()->withErrors(['email' => 'Invalid credentials']);
    }

    public function adminLogout()
    {
        session()->forget('admin_logged_in');
        return redirect()->route('adminLogin');
    }
}

