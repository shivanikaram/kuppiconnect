<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TutorLoginController extends Controller
{
    // Show the login form
    public function showTutorDashboardLoginForm()
    {
        return view('tutorDashboardLogin'); // Ensure this view is created for login
    }

    // Handle login
    public function tutorDashboardLogin(Request $request)
    {
        // Validate the form data
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        // Attempt to log the tutor in
        $credentials = $request->only('email', 'password');

        if (Auth::guard('tutor')->attempt($credentials)) {
            // Redirect to the tutor dashboard
            return redirect()->intended(route('tutorDashboard'));
        }
        // Authentication failed
        return back()->withErrors([
            'email' => 'These credentials do not match our records.',
        ]);
    }
}
