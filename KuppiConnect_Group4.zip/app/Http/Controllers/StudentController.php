<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    // Register a new student
    public function register(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:students_registration,email',
            'password' => 'required|string|min:8',
            'gender' => 'required|in:male,female',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'bio' => 'nullable|string',
        ]);
    
        if ($validator->fails()) {
            return redirect()->route('registerForm')
                             ->withErrors($validator)
                             ->withInput();
        }
    
        // Handle image upload if provided
        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('public/images');
        }

        // Check if the email is already taken before creating a new student
    $existingStudent = \App\Models\Student::where('email', $request->email)->first();
    
    if ($existingStudent) {
        return back()->with('error', 'This email is already registered.');
    }
    
        // Create the new student
        $student = \App\Models\Student::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'gender' => $request->gender,
            'image' => $imagePath,
            'bio' => $request->bio,
        ]);
    
        return redirect()->route('login')->with('success', 'Registration successful! Please log in.');
    }
}
