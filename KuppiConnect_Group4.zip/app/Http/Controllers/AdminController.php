<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;

class AdminController extends Controller
{
    public function store(Request $request)
    {
        // Validate input
        $request->validate([
            'email' => 'required|email|unique:admin_login,email',
            'password' => 'required|min:6',
        ]);

        // Hash the password
        $hashedPassword = Hash::make($request->password);

        // Create the admin
        Admin::create([
            'email' => $request->email,
            'password' => $hashedPassword,
        ]);

        return redirect()->route('adminLogin')->with('success', 'Admin created successfully!');
    }
}
