<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tutor;
use App\Models\Module;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TutorController extends Controller
{
    // Register a new tutor
    public function registerTutor(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:tutors_registration,email',
            'password' => 'required|string|min:8',
            'gender' => 'required|in:male,female',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'department' => 'required|in:Computer Science,Cyber Security,Software Engineering',
            'bio' => 'nullable|string',
            'achievements' => 'nullable|string',
        ]);
    
        if ($validator->fails()) {
            return redirect()->route('registerFormTutor')
                             ->withErrors($validator)
                             ->withInput();
        }
    
        // Handle image upload if provided
        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('public/images');
        }

        // Check if the email is already taken before creating a new student
    $existingTutor = \App\Models\Tutor::where('email', $request->email)->first();
    
    if ($existingTutor) {
        return back()->with('error', 'This email is already registered.');
    }
    
        // Create the new tutor
        $tutor = \App\Models\Tutor::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'gender' => $request->gender,
            'image' => $imagePath,
            'department' => $request->department,
            'bio' => $request->bio,
            'achievements' => $request->achievements,
        ]);
    
        return redirect()->route('loginTutor')->with('success', 'Registration successful! Please log in.');
    }

    public function store(Request $request)
{
    // Validate input
    $request->validate([
       'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:tutors_registration,email',
            'password' => 'required|string|min:8',
            'gender' => 'required|in:male,female',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'department' => 'required|in:Computer Science,Cyber Security,Software Engineering',
            'bio' => 'nullable|string',
            'achievements' => 'nullable|string',
    ]);

    // Handle image upload
    $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('public/images');
        }

    // Create Tutor
    Tutor::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        'gender' => $request->gender,
        'image' => $imagePath,
        'department' => $request->department,
        'bio' => $request->bio,
        'achievements' => $request->achievements,
    ]);

    return redirect()->route('tutors')->with('success', 'Tutor registered successfully.');
}
// Retrieve and display all tutors
public function getAllTutors()
{
    // Retrieve all tutors
    $tutors = Tutor::all();

    // Pass the data to the view
    return view('tutors', compact('tutors'));
}

public function showProfile($tutor_id)
{
    // Find the tutor by its primary key
    $tutor = Tutor::findOrFail($tutor_id);
    return view('tutorProfile', compact('tutor'));
}



// Show the tutor dashboard
public function showDashboard()
{
    // Retrieve the currently authenticated tutor using the 'tutor' guard
    $tutor = Auth::guard('tutor')->user();  // Fetch the tutor details

    // Pass tutor data to the view
    return view('tutorDashboard', compact('tutor'));
}

public function addModule(Request $request)
{
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'description' => 'required|string',
    ]);

    // Ensure the user is authenticated and is a tutor
    if (Auth::check() && Auth::user()->tutor) {
        $module = new Module();
        $module->name = $validated['name'];
        $module->description = $validated['description'];
        $module->tutor_id = auth::user()->tutor->tutor_id; // Use tutor's ID
        $module->save();

        return redirect()->route('tutorDashboard')->with('success', 'Module added successfully!');
    }

    return redirect()->route('tutorDashboard')->with('error', 'You must be a tutor to add a module.');
}



}
