<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Tutor extends Authenticatable
{
    use Notifiable;

    protected $table = 'tutors_registration';
    protected $primaryKey = 'tutor_id';

    protected $fillable = ['name', 'email', 'password', 'gender','phone_number', 'image', 'department', 'bio', 'achievements'];

    // Relationship: A tutor has many modules
    public function modules()
    {
        return $this->hasMany(Module::class, 'tutor_id');
    }
}


