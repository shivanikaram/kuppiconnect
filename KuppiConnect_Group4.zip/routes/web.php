<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TutorController;
use App\Http\Controllers\AdminLoginController;
use App\Http\Controllers\TutorLoginController;
use App\Http\Controllers\ModuleController;

Route::view('/', 'index')->name('index');

// Student Registration and Login
Route::view('/loginStu', 'loginStu')->name('loginStu');
Route::view('/loginTut', 'loginTut')->name('loginTut');
Route::view('/registerStu', 'registerStu')->name('registerStu');
Route::view('/registerTut', 'registerTut')->name('registerTut');
Route::view('/tutors', 'tutors')->name('tutors');

// Authentication Routes for students
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('registerForm');
Route::post('/register', [AuthController::class, 'register'])->name('registerStu');

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('loginForm');
Route::post('/login', [AuthController::class, 'login'])->name('loginStu');

// Admin dashboard route
// Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');

// Authentication Routes for Tutors
Route::get('/registerTutor', [AuthController::class, 'showTutorRegistrationForm'])->name('registerFormTutor');
Route::post('/registerTutor', [AuthController::class, 'registerTutor'])->name('registerTut');

Route::get('/loginTutor', [AuthController::class, 'showTutorLoginForm'])->name('loginFormTutor');
Route::post('/loginTutor', [AuthController::class, 'loginTutor'])->name('loginTut');

// Default Home Route
Route::get('/', function () {
    return view('index');
})->name('index');

//admin login
Route::get('/admin/login', [AdminLoginController::class, 'showAdminLoginForm'])->name('adminLogin');
Route::post('/admin/login', [AdminLoginController::class, 'adminLogin'])->name('adminloginSubmit');
Route::get('/admin/dashboard', function () {
    return view('adminDashboard');
})->name('adminDashboard');
Route::post('/admin/logout', [AdminLoginController::class, 'adminLogout'])->name('adminLogout');

//tutor profile cards
Route::get('/tutors', [TutorController::class, 'getAllTutors'])->name('tutors');

//login to tutor dashboard
Route::get('/tutor/login', [TutorLoginController::class, 'showTutorDashboardLoginForm'])->name('tutorDashboardLogin');
Route::post('/tutor/login', [TutorLoginController::class, 'tutorDashboardLogin'])->name('tutorloginSubmit');
Route::get('/tutor/dashboard', function () {
    return view('tutorDashboard');
})->name('tutorDashboard');
Route::middleware('auth:tutor')->get('/tutor/profile', [TutorController::class, 'showProfile'])->name('showTutorProfile');

Route::get('/tutor/dashboard', [TutorController::class, 'showDashboard'])->name('tutorDashboard');

Route::get('/tutor/{tutor_id}', [TutorController::class, 'showProfile'])->name('tutorProfile');

Route::post('/tutor/addModule', [ModuleController::class, 'store'])->name('tutorAddModule');


