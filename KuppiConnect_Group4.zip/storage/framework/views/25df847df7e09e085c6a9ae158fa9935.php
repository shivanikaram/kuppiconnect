<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>View Tutor Profile</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-gray-100 text-gray-800">

<!-- Navbar -->
<nav class="bg-blue-400 p-4" x-data="{ open: false }">
    <div class="flex items-center justify-between">
        <div class="text-2xl font-bold text-white">KuppiConnect</div>
        <div class="sm:hidden">
            <button @click="open = !open" class="text-white focus:outline-none">
                <svg x-show="!open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg x-show="open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div class="hidden sm:flex space-x-6 text-white font-semibold">
            <a href="<?php echo e(route('index')); ?>" class="text-white hover:underline">Home</a>
            <a href="<?php echo e(route('tutors')); ?>" class="text-white hover:underline">View Tutors</a>
            <a href="/services" class="text-white hover:underline">Our Services</a>
        </div>
        <div class="hidden sm:flex space-x-4 text-white">
            <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-user"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
        </div>
    </div>
    <div x-show="open" class="sm:hidden">
        <div class="flex flex-col bg-blue-500 text-white p-4 space-y-2">
            <a href="<?php echo e(route('index')); ?>" class="hover:text-gray-200">Home</a>
            <a href="<?php echo e(route('tutors')); ?>" class="hover:text-gray-200">View Tutors</a>
            <a href="/services" class="hover:text-gray-200">Our Services</a>
            <div class="flex space-x-4">
                <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-user"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
            </div>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container mx-auto mt-10">
        <div class="bg-white shadow-lg rounded-lg p-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <!-- Profile Section -->
            <div class="col-span-1 lg:col-span-1 flex flex-col items-center bg-gray-50 p-6 rounded-lg border shadow-sm">
                <img src="<?php echo e($tutor->image ? asset('images/' . $tutor->image) : ''); ?>" alt="" class="w-32 h-32 rounded-full object-cover">
                <h3 class="text-2xl font-bold mt-4"><?php echo e($tutor->name); ?></h3>
                <p class="text-gray-600"><?php echo e(ucfirst($tutor->gender)); ?></p>
                <div class="flex items-center justify-center space-x-6 mt-4">
                <a href="mailto:<?php echo e($tutor->email); ?>" class="text-gray-500 hover:text-gray-600"><i class="fas fa-envelope"></i> <?php echo e($tutor->email); ?></a>
                <a href="tel:<?php echo e($tutor->phone_number); ?>" class="text-gray-500 hover:text-gray-600"><i class="fas fa-phone-alt"></i> <?php echo e($tutor->phone_number); ?></a>
                </div>
            </div>

            <!-- Bio and Achievements Section -->
            <div class="col-span-1 lg:col-span-2 space-y-6">
                <div class="bg-gray-50 p-6 rounded-lg border shadow-sm">
                    <h4 class="text-xl font-semibold text-blue-600">Bio</h4>
                    <p class="text-gray-700"><?php echo e($tutor->bio ?? 'No bio available.'); ?></p>
                </div>

                <div class="bg-gray-50 p-6 rounded-lg border shadow-sm">
                    <h4 class="text-xl font-semibold text-blue-600">Achievements</h4>
                    <p class="text-gray-700"><?php echo e($tutor->achievements ?? 'No achievements available.'); ?></p>
                </div>

                <!-- Modules Section -->
                <div class="bg-gray-50 p-6 rounded-lg border shadow-sm">
                    <h4 class="text-xl font-semibold text-blue-600">Modules</h4>
                    <ul class="list-disc pl-6 text-gray-700">
                        <li>Introduction to Programming</li>
                        <li>Data Structures and Algorithms</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\user\Documents\KuppiConnect\resources\views/tutorProfile.blade.php ENDPATH**/ ?>