<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Explore Tutors</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-gray-100 text-gray-800">

<!-- Navbar -->
<nav class="bg-blue-400 p-4" x-data="{ open: false }">
    <div class="flex items-center justify-between">
        <!-- Logo -->
        <div class="text-2xl font-bold text-white">
            KuppiConnect
        </div>

        <!-- Hamburger Icon - Visible only on small screens -->
        <div class="sm:hidden">
            <button @click="open = !open" class="text-white focus:outline-none">
                <svg x-show="!open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg x-show="open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Links - Hidden on small screens, shown on larger screens -->
        <div class="hidden sm:flex space-x-6 text-white font-semibold">
            <a href="<?php echo e(route('index')); ?>" class="text-white hover:underline">Home</a>
            <a href="<?php echo e(route('tutors')); ?>" class="text-white hover:underline">View Tutors</a>
            <a href="/services" class="text-white hover:underline">Our Services</a>
        </div>

        <!-- Icons - Hidden on small screens, shown on larger screens -->
        <div class="hidden sm:flex space-x-4 text-white">
            <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-user"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
        </div>
    </div>

    <!-- Mobile Menu - Visible when open is true -->
    <div x-show="open" class="sm:hidden">
        <div class="flex flex-col bg-blue-500 text-white p-4 space-y-2">
            <a href="<?php echo e(route('index')); ?>" class="hover:text-gray-200">Home</a>
            <a href="<?php echo e(route('tutors')); ?>" class="hover:text-gray-200">View Tutors</a>
            <a href="/services" class="hover:text-gray-200">Our Services</a>
            <div class="flex space-x-4">
                <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-user"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
            </div>
        </div>
    </div>
</nav>

<!-- Page Container -->
<div class="container mx-auto px-4">
    <!-- Header Section -->
    <header class="py-8 text-center">
        <h1 class="text-3xl font-bold">Explore Tutors</h1>
        <p class="text-gray-600">A community of volunteer tutors</p>
    </header>

    <!-- Main Content Section -->
    <div class="space-y-6">
        <!-- Underlined Header Section -->
        <div class="flex items-center justify-between border-b-2 border-black pb-2">
            <h2 class="text-xl font-bold">Subjects</h2>
            <div class="flex items-center border border-gray-300 rounded-md overflow-hidden">
                <input type="text" placeholder="Search Tutors" class="p-2 outline-none">
                <button class="p-2 text-gray-500">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>

        <!-- Main Content Area with Sidebar and Tutor Cards -->
        <div class="flex space-x-8">
            <!-- Subjects Sidebar -->
            <aside class="w-1/4">
                <ul class="space-y-2">
                    <li><a href="#" class="text-gray-700 hover:text-blue-500">Computer Science</a></li>
                    <li><a href="#" class="text-gray-700 hover:text-blue-500">Cyber Security</a></li>
                    <li><a href="#" class="text-gray-700 hover:text-blue-500">Software Engineering</a></li>
                </ul>
            </aside>

            <!-- Tutors Section -->
            <main class="flex-1">
                <!-- Tutor Cards Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Tutor Card -->
                        <div class="bg-white shadow-md rounded-lg p-4">
                        <img src="<?php echo e($tutor->image ? asset('images/' . $tutor->image) : ''); ?>" alt="" class="w-32 h-32 object-cover rounded-full">


                            <div class="mt-4">
                                <h3 class="text-lg font-bold"><?php echo e($tutor->name); ?></h3>
                                <p class="text-gray-600"><?php echo e(ucfirst($tutor->gender)); ?></p>
                                <p class="text-gray-600"><?php echo e($tutor->department); ?></p>
                            </div>
                            <div class="flex items-center mt-4 text-blue-500 space-x-4">
                                <span class="flex items-center">
                                    <i class="fas fa-star mr-1"></i> <?php echo e($tutor->reviews_count ?? 0); ?>

                                </span>
                                <span class="flex items-center">
                                    <i class="fas fa-thumbs-up mr-1"></i> <?php echo e($tutor->likes ?? 0); ?>

                                </span>
                            </div>
                            <div class="mt-2 flex gap-2">
                                <a href="<?php echo e(route('tutorProfile', $tutor->tutor_id)); ?>" class="flex-1 bg-blue-500 text-center text-white py-2 rounded-md hover:bg-blue-400">View Profile</a>
                            </div>
                            <div class="mt-2 flex gap-2">
                                <a href="#" class="flex-1 bg-blue-500 text-center text-white py-2 rounded-md hover:bg-blue-400">Message</a>
                                <a href="#" class="flex-1 bg-blue-500 text-center text-white py-2 rounded-md hover:bg-blue-400">Session Schedule</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </main>
        </div>
    </div>
</div>

<br>
<!-- Footer -->
<footer style="background-color: #8AB6D7; width: 100%;">
  <div class="px-6 py-8 sm:px-12 md:px-20 max-w-full mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 sm:gap-12 md:gap-16">
    
    <!-- About KuppiConnect -->
    <div class="space-y-4">
      <h3 class="text-xl sm:text-2xl font-bold text-black">KuppiConnect</h3>
      <p class="text-white text-sm sm:text-base">Empowering university students through personalized learning and mentorship.</p>
      <p class="text-white text-sm sm:text-base">Follow us on social media for updates and educational resources.</p>
      <div class="flex space-x-4 text-2xl sm:text-3xl text-white">
        <a href="https://facebook.com" class="hover:text-blue-800"><i class="fab fa-facebook-square"></i></a>
        <a href="https://twitter.com" class="hover:text-blue-500"><i class="fab fa-twitter-square"></i></a>
        <a href="https://instagram.com" class="hover:text-pink-500"><i class="fab fa-instagram"></i></a>
        <a href="https://youtube.com" class="hover:text-red-500"><i class="fab fa-youtube"></i></a>
      </div>
      <p class="text-white text-sm sm:text-base">Contact Us</p>
      <p class="text-white text-sm sm:text-base">0771234567</p>
      <p class="text-white text-sm sm:text-base"><a href="mailto:kuppiconnect@gmail.com" class="hover:underline">Mail Us</a></p>
    </div>
    
    <!-- Company Information -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Company</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">About Us</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Our Mission</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Blog</p>
    </div>
    
    <!-- Legal Information -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Legal</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">FAQs</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Terms of Service</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Privacy Policy</p>
    </div>
    
    <!-- Resources Section -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Resources</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Tutoring Resources</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Help Center</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Partnerships</p>
    </div>
    
  </div>
  <div class="bg-blue-500 text-gray-200 text-center py-4">
    <p class="text-sm sm:text-base">&copy; 2024 KuppiConnect. All rights reserved.</p>
  </div>
</footer>
</html>
<?php /**PATH C:\Users\user\Documents\KuppiConnect\resources\views/tutors.blade.php ENDPATH**/ ?>