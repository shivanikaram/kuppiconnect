<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>KuppiConnect</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-gray-100 text-gray-800">

<!-- Navbar -->
<nav class="bg-blue-400 p-4" x-data="{ open: false }">
    <div class="flex items-center justify-between">
        <!-- Logo -->
        <div class="text-2xl font-bold text-white">
            KuppiConnect
        </div>

        <!-- Hamburger Icon -->
        <div class="sm:hidden">
            <button @click="open = !open" class="text-white focus:outline-none">
                <!-- Icon changes based on the 'open' state -->
                <svg x-show="!open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg x-show="open" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Links - Hidden on small screens, shown on larger screens -->
        <div class="hidden sm:flex space-x-6 text-white font-semibold">
        <a href="<?php echo e(route('index')); ?>" class="text-white hover:underline">Home</a>
            <a href="<?php echo e(route('tutors')); ?>" class="text-white hover:underline">View Tutors</a>
            <a href="/services" class="text-white hover:underline">Our Services</a>
            <a href="<?php echo e(route('tutorloginSubmit')); ?>" class="text-white hover:underline">Dashboard</a>
        </div>

        <!-- Icons - Hidden on small screens, shown on larger screens -->
        <div class="hidden sm:flex space-x-4 text-white">
            <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-user-circle"></i></a>
            <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
            <a href="<?php echo e(route('adminLogin')); ?>" class="hover:text-gray-200"><i class="fa fa-user-md"></i></a>
        </div>
    </div>

    <!-- Mobile Menu - Visible when open is true -->
    <div x-show="open" class="sm:hidden">
        <div class="flex flex-col bg-blue-500 text-white p-4 space-y-2">
            <a href="/" class="hover:text-gray-200">Home</a>
            <a href="/tutors" class="hover:text-gray-200">View Tutors</a>
            <a href="/services" class="hover:text-gray-200">Our Services</a>
            <a href="<?php echo e(route('tutorloginSubmit')); ?>" class="hover:text-gray-200">Dashboard</a>
            <div class="flex space-x-4">
                <a href="#" class="hover:text-gray-200"><i class="fas fa-search"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-user"></i></a>
                <a href="#" class="hover:text-gray-200"><i class="fas fa-comments"></i></a>
                <a href="<?php echo e(route('adminLogin')); ?>" class="hover:text-gray-200"><i class="fa fa-user-md"></i></a>
            </div>
        </div>
    </div>
</nav>

<!-- Main Banner Section -->
<section class="text-center py-10 bg-white">
    <h1 class="text-3xl font-bold mt-4">Welcome to Kuppi Culture</h1>
    <p class="text-xl text-gray-600 mt-2">Empowering University Learning</p>
    <img src="<?php echo e(asset('images/home.avif')); ?>" alt="Graduation Illustration" class="mx-auto" style="width: 500px;">
</section>

<!-- About Us Section -->
<section class="text-center py-8 px-4 bg-blue-50">
    <h2 class="text-2xl font-semibold mb-4">About Us</h2>
    <p class="text-gray-600 max-w-md mx-auto">
    Kuppi Connect is a platform dedicated to empowering university students by providing easy access to peer tutoring, personalized study sessions, and academic resources. Our mission is to support students in their educational journey through collaborative learning and expert guidance.
    </p>
</section>

<!-- Sign Up Section -->
<section class="text-center py-8 bg-blue-50 border-">
    <h2 class="text-2xl font-bold text-red-800 italic mb-6">Sign Up for Free!</h2>

    <!-- Student Sign-Up Button -->
    <div class="bg-white shadow-lg rounded-lg max-w-xl mx-auto py-6 px-8 mb-6 mt-10">
    <h3 class="text-xl font-bold text-blue-600 text-center mb-2">I am a Student</h3>
    <p class="text-gray-600 text-center mb-4">Get help with homework, improve your grades, and ace your exams with personalized tutoring.</p>
    <a href="<?php echo e(route('loginStu')); ?>" class="block text-center bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md transition duration-200">Click here to Sign Up</a>
    </div>

    <!-- Tutor Sign-Up Button -->
    <div class="bg-white shadow-lg rounded-lg max-w-xl mx-auto py-6 px-8 mb-6 mt-10">
    <h3 class="text-xl font-bold text-blue-600 text-center mb-2">I am a Tutor</h3>
    <p class="text-gray-600 text-center mb-4">Share your expertise, mentor fellow students, and build your tutoring experience while helping others succeed.</p>
    <a href="<?php echo e(route('loginTut')); ?>" class="block text-center bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md transition duration-200">Click here to Sign Up</a>
    </div>
</section>

</body>

<!-- Footer -->
<footer style="background-color: #8AB6D7; width: 100%;">
  <div class="px-6 py-8 sm:px-12 md:px-20 max-w-full mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 sm:gap-12 md:gap-16">
    
    <!-- About KuppiConnect -->
    <div class="space-y-4">
      <h3 class="text-xl sm:text-2xl font-bold text-black">KuppiConnect</h3>
      <p class="text-white text-sm sm:text-base">Empowering university students through personalized learning and mentorship.</p>
      <p class="text-white text-sm sm:text-base">Follow us on social media for updates and educational resources.</p>
      <div class="flex space-x-4 text-2xl sm:text-3xl text-white">
        <a href="https://facebook.com" class="hover:text-blue-800"><i class="fab fa-facebook-square"></i></a>
        <a href="https://twitter.com" class="hover:text-blue-500"><i class="fab fa-twitter-square"></i></a>
        <a href="https://instagram.com" class="hover:text-pink-500"><i class="fab fa-instagram"></i></a>
        <a href="https://youtube.com" class="hover:text-red-500"><i class="fab fa-youtube"></i></a>
      </div>
      <p class="text-white text-sm sm:text-base">Contact Us</p>
      <p class="text-white text-sm sm:text-base">0771234567</p>
      <p class="text-white text-sm sm:text-base"><a href="mailto:kuppiconnect@gmail.com" class="hover:underline">Mail Us</a></p>
    </div>
    
    <!-- Company Information -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Company</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">About Us</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Our Mission</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Blog</p>
    </div>
    
    <!-- Legal Information -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Legal</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">FAQs</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Terms of Service</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Privacy Policy</p>
    </div>
    
    <!-- Resources Section -->
    <div class="space-y-2 sm:space-y-4">
      <h4 class="text-lg sm:text-xl font-semibold text-black">Resources</h4>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Tutoring Resources</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Help Center</p>
      <p class="text-white text-sm sm:text-base cursor-pointer hover:text-gray-300">Partnerships</p>
    </div>
    
  </div>
  <div class="bg-blue-500 text-gray-200 text-center py-4">
    <p class="text-sm sm:text-base">&copy; 2024 KuppiConnect. All rights reserved.</p>
  </div>
</footer>
</html>
<?php /**PATH C:\Users\user\Documents\KuppiConnect\resources\views/index.blade.php ENDPATH**/ ?>