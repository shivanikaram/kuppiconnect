<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.0/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center bg-gray-100">
    <div class="w-full max-w-md bg-white shadow-lg p-8">
        <h2 class="text-2xl font-bold text-center mb-4">Create an Account</h2>

        <!-- Show errors if any -->
        @if ($errors->any())
            <div class="bg-red-500 text-white p-4 rounded">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        
        <form action="{{ route('registerTut') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="mb-4">
                <label for="name" class="block text-gray-700">Name</label>
                <input type="text" id="name" name="name" value="{{ old('name') }}" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>

            <div class="mb-4">
                <label for="email" class="block text-gray-700">Email</label>
                <input type="email" id="email" name="email" value="{{ old('email') }}" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>

            <div class="mb-4">
                <label for="password" class="block text-gray-700">Password</label>
                <input type="password" id="password" name="password" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>

            <div class="mb-4">
                <label for="gender" class="block text-gray-700">Gender</label>
                <select id="gender" name="gender" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                    <option value="">Select Gender</option>
                    <option value="male" {{ old('gender') == 'male' ? 'selected' : '' }}>Male</option>
                    <option value="female" {{ old('gender') == 'female' ? 'selected' : '' }}>Female</option>
                </select>
            </div>
            <div class="mb-4">
                <label for="phone_number" class="block text-gray-700">Phone Number</label>
                <input type="text" id="phone_number" name="phone_number" value="{{ old('phone_number') }}" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">

            <div class="mb-4">
                <label for="image" class="block text-gray-700">Profile Picture</label>
                <input type="file" id="image" name="image" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            </div>

            <div class="mb-4">
        <label for="department" class="block text-gray-700">Department</label>
        <select id="department" name="department" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
            <option value="">Select Department</option>
            <option value="Computer Science" {{ old('department') == 'Computer Science' ? 'selected' : '' }}>Computer Science</option>
            <option value="Cyber Security" {{ old('department') == 'Cyber Security' ? 'selected' : '' }}>Cyber Security</option>
            <option value="Software Engineering" {{ old('department') == 'Software Engineering' ? 'selected' : '' }}>Software Engineering</option>
        </select>
    </div>
            <div class="mb-4">
                <label for="bio" class="block text-gray-700">Bio</label>
                <textarea id="bio" name="bio" rows="3" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">{{ old('bio') }}</textarea>
            </div>

            <div class="mb-4">
                <label for="achievements" class="block text-gray-700">Achievements</label>
                <textarea id="achievements" name="achievements" rows="3" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">{{ old('achievements') }}</textarea>
            
            </div>
            <button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md transition duration-200">
                Register
            </button>
        </form>
    </div>
</body>
</html>
